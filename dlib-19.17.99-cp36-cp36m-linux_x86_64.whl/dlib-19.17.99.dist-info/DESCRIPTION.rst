See http://dlib.net for documentation.


